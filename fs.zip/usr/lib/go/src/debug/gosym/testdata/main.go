package main

func linefrompc()
func pcfromline()

func main() {
	// Prevent GC of our test symbols
	linefrompc()
	pcfromline()
}
