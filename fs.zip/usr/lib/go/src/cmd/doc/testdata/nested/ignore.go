//go:build ignore
// +build ignore

// Ignored package
package nested
