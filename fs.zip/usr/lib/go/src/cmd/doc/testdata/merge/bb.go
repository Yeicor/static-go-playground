// Package comment B.
package merge

// B doc.
func B() {
	// B comment.
}
