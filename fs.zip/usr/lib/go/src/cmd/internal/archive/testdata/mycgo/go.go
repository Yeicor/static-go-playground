package mycgo

// void c1(void);
// void c2(void);
import "C"
